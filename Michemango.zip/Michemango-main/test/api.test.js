// Pruebas del servidor: se ejecutan con `npm test` y no escriben en solicitudes.json
// (solo envían datos inválidos al formulario) ni consultan a Anthropic.
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");

const app = require("../src/server");
const NEGOCIO = require("../public/js/negocio");
const instrucciones = require("../src/prompts/chatbotSistema");

let servidor;
let base;

// Levantamos el servidor en un puerto libre que elige el sistema.
before(
  () =>
    new Promise((resolver) => {
      servidor = app.listen(0, () => {
        base = `http://127.0.0.1:${servidor.address().port}`;
        resolver();
      });
    })
);

after(() => servidor.close());

function enviarJson(ruta, cuerpo) {
  return fetch(`${base}${ruta}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(cuerpo),
  });
}

test("los productos tienen todos los campos que usan la página y la IA", () => {
  const ids = new Set();
  for (const producto of NEGOCIO.productos) {
    assert.ok(Number.isInteger(producto.id) && !ids.has(producto.id), `id repetido o inválido: ${producto.id}`);
    ids.add(producto.id);
    assert.ok(producto.nombre, "falta el nombre");
    assert.ok(Number.isInteger(producto.precio) && producto.precio > 0, `${producto.nombre}: precio inválido`);
    for (const campo of ["descripcion", "descripcionCorta", "emoji", "estilo"]) {
      assert.ok(producto[campo], `${producto.nombre}: falta ${campo}`);
    }
    assert.ok(Array.isArray(producto.gustos) && producto.gustos.length, `${producto.nombre}: faltan gustos`);
  }
  assert.match(NEGOCIO.whatsapp, /^\d{10,15}$/, "el WhatsApp debe tener solo dígitos con código de país");
});

test("la página principal se sirve desde public/", async () => {
  const respuesta = await fetch(`${base}/`);
  assert.equal(respuesta.status, 200);
  assert.match(await respuesta.text(), /js\/negocio\.js/);
});

test("GET /api/productos devuelve el catálogo de negocio.js", async () => {
  const respuesta = await fetch(`${base}/api/productos`);
  assert.equal(respuesta.status, 200);
  assert.deepEqual(await respuesta.json(), NEGOCIO.productos);
});

test("las instrucciones de la IA incluyen cada producto, su precio y el WhatsApp", () => {
  const formato = new Intl.NumberFormat("es-CO");
  for (const producto of NEGOCIO.productos) {
    assert.ok(instrucciones.includes(`${producto.nombre}: $${formato.format(producto.precio)}`), producto.nombre);
  }
  assert.ok(instrucciones.includes(`https://wa.me/${NEGOCIO.whatsapp}`));
});

test("el formulario rechaza un teléfono inválido", async () => {
  const respuesta = await enviarJson("/api/contacto", {
    nombre: "Prueba",
    telefono: "12",
    tipo: "duda",
    mensaje: "Hola",
  });
  assert.equal(respuesta.status, 400);
  assert.match((await respuesta.json()).error, /teléfono/);
});

test("el formulario rechaza un tipo de solicitud desconocido", async () => {
  const respuesta = await enviarJson("/api/contacto", {
    nombre: "Prueba",
    telefono: "3001234567",
    tipo: "otro",
    mensaje: "Hola",
  });
  assert.equal(respuesta.status, 400);
});

test("el chat rechaza un historial que no empieza con el cliente", async () => {
  const respuesta = await enviarJson("/api/chat", {
    mensajes: [{ role: "assistant", content: "Hola" }],
  });
  assert.equal(respuesta.status, 400);
});

test("el chat rechaza mensajes del cliente de más de 500 caracteres", async () => {
  const respuesta = await enviarJson("/api/chat", {
    mensajes: [{ role: "user", content: "a".repeat(501) }],
  });
  assert.equal(respuesta.status, 400);
});

test("el panel y su API exigen iniciar sesión", async () => {
  const panel = await fetch(`${base}/admin`, { redirect: "manual" });
  assert.equal(panel.status, 302);
  assert.equal(panel.headers.get("location"), "/admin/login");

  const api = await fetch(`${base}/api/admin/solicitudes`);
  assert.equal(api.status, 401);
});

test("una ruta de API inexistente responde 404 en JSON", async () => {
  const respuesta = await fetch(`${base}/api/no-existe`);
  assert.equal(respuesta.status, 404);
  assert.ok((await respuesta.json()).error);
});
