// Controlamos el botón flotante, la ventana de chat y sus mensajes.
const botonAbrirChat = document.getElementById("chatbot-abrir");
const botonCerrarChat = document.getElementById("chatbot-cerrar");
const panelChat = document.getElementById("chatbot-panel");
const listaMensajes = document.getElementById("chatbot-mensajes");
const formularioChat = document.getElementById("chatbot-form");
const campoMensajeChat = document.getElementById("chatbot-texto");
const botonEnviarChat = formularioChat.querySelector('button[type="submit"]');
const sugerenciasChat = document.getElementById("chatbot-sugerencias");
let historialChat = [];

// El recomendador local y los botones de pedido usan el catálogo de negocio.js.
const PRODUCTOS_CHAT = NEGOCIO.productos;

// Mostramos el chat y enfocamos el campo para facilitar el uso con teclado.
function abrirChat() {
    panelChat.hidden = false;
    botonAbrirChat.setAttribute("aria-expanded", "true");
    campoMensajeChat.focus();
}

// Ocultamos el panel sin borrar la conversación visible.
function cerrarChat() {
    panelChat.hidden = true;
    botonAbrirChat.setAttribute("aria-expanded", "false");
    botonAbrirChat.focus();
}

// Creamos burbujas como texto plano; solo los enlaces de WhatsApp se vuelven clicables.
function agregarMensaje(texto, esDelAsistente) {
    const mensaje = document.createElement("p");
    mensaje.className = esDelAsistente
        ? "chatbot-message chatbot-message--bot"
        : "chatbot-message chatbot-message--user";

    texto.split(/(https:\/\/wa\.me\/\S+)/).forEach((parte) => {
        if (/^https:\/\/wa\.me\//.test(parte)) {
            const url = parte.replace(/[.,;)]+$/, "");
            const enlace = document.createElement("a");
            enlace.href = url;
            enlace.target = "_blank";
            enlace.rel = "noopener noreferrer";
            enlace.textContent = "Pedir por WhatsApp";
            mensaje.append(enlace, parte.slice(url.length));
        } else {
            mensaje.append(parte);
        }
    });

    listaMensajes.append(mensaje);
    listaMensajes.scrollTop = listaMensajes.scrollHeight;
    return mensaje;
}

// Si la respuesta menciona un producto, ofrecemos un botón con el pedido ya escrito.
function agregarBotonPedido(texto) {
    const producto = PRODUCTOS_CHAT.find((item) => texto.includes(item.nombre));
    if (!producto) return;

    const enlace = document.createElement("a");
    enlace.className = "chatbot-pedido";
    enlace.href = enlaceWhatsapp(
        `Hola, ${NEGOCIO.nombre}. Quiero pedir 1 ${producto.nombre} ($${formatPrice(producto.precio)}).`
    );
    enlace.target = "_blank";
    enlace.rel = "noopener noreferrer";
    enlace.textContent = `Pedir ${producto.nombre} por WhatsApp`;
    listaMensajes.append(enlace);
    listaMensajes.scrollTop = listaMensajes.scrollHeight;
}

function mostrarEscribiendo() {
    const indicador = document.createElement("p");
    indicador.className = "chatbot-message chatbot-message--bot chatbot-escribiendo";
    indicador.setAttribute("aria-label", "El asesor está escribiendo");
    indicador.append(
        document.createElement("span"),
        document.createElement("span"),
        document.createElement("span")
    );
    listaMensajes.append(indicador);
    listaMensajes.scrollTop = listaMensajes.scrollHeight;
    return indicador;
}

// Lee montos como "18000", "$18.000", "18 mil" o "18k".
function leerPresupuesto(texto) {
    const conMil = texto.match(/(\d+(?:[.,]\d+)?)\s*(mil|k)\b/);
    if (conMil) return Math.round(parseFloat(conMil[1].replace(",", ".")) * 1000);

    const numeros = (texto.match(/\d[\d.,]*/g) || [])
        .map((numero) => Number(numero.replace(/[.,]/g, "")))
        .filter((numero) => numero >= 1000);
    return numeros.length ? Math.max(...numeros) : null;
}

// Recomendador sencillo por gustos y presupuesto para el sitio publicado sin servidor.
function recomendacionLocal(texto) {
    const limpio = texto.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
    const presupuesto = leerPresupuesto(limpio);
    const coincidencias = PRODUCTOS_CHAT.filter((producto) =>
        producto.gustos.some((gusto) => limpio.includes(gusto))
    );
    const cierre = `\n¿Te la preparamos? Haz tu pedido aquí: https://wa.me/${whatsappNumber}`;

    if (/precio|cuanto|menu|carta|opciones|productos/.test(limpio) && !coincidencias.length && !presupuesto) {
        const lista = PRODUCTOS_CHAT.map((p) => `• ${p.nombre}: $${formatPrice(p.precio)}`).join("\n");
        return `Estas son nuestras miches:\n${lista}\n¿Qué sabor te provoca: dulce, ácido o picante?`;
    }

    if (!coincidencias.length && !presupuesto) {
        return "¡Cuéntame un poquito más! ¿Te gusta lo dulce, lo ácido o lo picante? Y si quieres, dime cuánto quieres gastar.";
    }

    const candidatos = coincidencias.length ? coincidencias : PRODUCTOS_CHAT;
    const alcanzan = presupuesto
        ? candidatos.filter((producto) => producto.precio <= presupuesto)
        : candidatos;

    if (!alcanzan.length) {
        const masEconomica = PRODUCTOS_CHAT.reduce((a, b) => (a.precio < b.precio ? a : b));
        if (presupuesto && presupuesto < masEconomica.precio) {
            return `Con $${formatPrice(presupuesto)} todavía no alcanza para una miche. La más económica es la ${masEconomica.nombre} a $${formatPrice(masEconomica.precio)}.${cierre}`;
        }
        const opcion = PRODUCTOS_CHAT
            .filter((producto) => producto.precio <= presupuesto)
            .sort((a, b) => b.precio - a.precio)[0];
        return `La miche de ese sabor se pasa de tu presupuesto, pero con $${formatPrice(presupuesto)} te recomiendo la ${opcion.nombre} ($${formatPrice(opcion.precio)}): ${opcion.descripcionCorta}.${cierre}`;
    }

    // Damos la opción más completa que entra en el presupuesto.
    const elegida = [...alcanzan].sort((a, b) => b.precio - a.precio)[0];
    const extra = presupuesto && presupuesto >= elegida.precio * 2
        ? ` ¡Y te alcanza para ${Math.floor(presupuesto / elegida.precio)}!`
        : "";
    return `Te recomiendo la ${elegida.nombre} a $${formatPrice(elegida.precio)}: ${elegida.descripcionCorta}.${extra}${cierre}`;
}

botonAbrirChat.addEventListener("click", abrirChat);
botonCerrarChat.addEventListener("click", cerrarChat);

panelChat.addEventListener("keydown", (evento) => {
    if (evento.key === "Escape") cerrarChat();
});

// Enter envía; Shift + Enter agrega una línea nueva.
campoMensajeChat.addEventListener("keydown", (evento) => {
    if (evento.key === "Enter" && !evento.shiftKey) {
        evento.preventDefault();
        formularioChat.requestSubmit();
    }
});

sugerenciasChat.addEventListener("click", (evento) => {
    const boton = evento.target.closest("button[data-sugerencia]");
    if (!boton) return;
    campoMensajeChat.value = boton.dataset.sugerencia;
    formularioChat.requestSubmit();
});

// Pide la respuesta a la IA del servidor; devuelve null si el servidor no está disponible.
async function respuestaDelServidor(mensajesParaEnviar) {
    if (!API_DISPONIBLE) return null;

    try {
        const respuesta = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ mensajes: mensajesParaEnviar }),
        });
        const resultado = await respuesta.json();
        return respuesta.ok && resultado.respuesta ? resultado.respuesta : null;
    } catch {
        return null;
    }
}

// Enviamos el historial reciente para que el asistente pueda entender el contexto.
formularioChat.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    const mensaje = campoMensajeChat.value.trim();
    if (!mensaje || botonEnviarChat.disabled) return;

    sugerenciasChat.hidden = true;
    agregarMensaje(mensaje, false);
    campoMensajeChat.value = "";
    campoMensajeChat.disabled = true;
    botonEnviarChat.disabled = true;
    const indicadorCarga = mostrarEscribiendo();

    const mensajesParaEnviar = [...historialChat, { role: "user", content: mensaje }].slice(-9);
    if (mensajesParaEnviar[0] && mensajesParaEnviar[0].role === "assistant") {
        mensajesParaEnviar.shift();
    }

    // Si la IA no responde (sin servidor o sin API key), contesta el recomendador local.
    let respuesta = await respuestaDelServidor(mensajesParaEnviar);
    if (!respuesta) {
        await new Promise((resolver) => setTimeout(resolver, 600));
        respuesta = recomendacionLocal(mensaje);
    }

    indicadorCarga.remove();
    agregarMensaje(respuesta, true);
    agregarBotonPedido(respuesta);

    historialChat = [...mensajesParaEnviar, { role: "assistant", content: respuesta }].slice(-9);
    if (historialChat[0] && historialChat[0].role === "assistant") {
        historialChat.shift();
    }

    campoMensajeChat.disabled = false;
    botonEnviarChat.disabled = false;
    campoMensajeChat.focus();
});
