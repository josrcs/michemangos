// Animaciones de aparición al hacer scroll y enlace activo del menú.
// Usa la constante `menu` definida en menu.js.

// Los grupos marcados con data-escalonar aparecen uno detrás de otro.
document.querySelectorAll("[data-escalonar]").forEach((grupo) => {
    grupo.querySelectorAll(":scope > .revelar").forEach((elemento, indice) => {
        elemento.style.setProperty("--retraso", `${indice * 0.12}s`);
    });
});

const elementosRevelar = document.querySelectorAll(".revelar");

if ("IntersectionObserver" in window) {
    const observador = new IntersectionObserver(
        (entradas) => {
            entradas.forEach((entrada) => {
                if (entrada.isIntersecting) {
                    entrada.target.classList.add("visible");
                    observador.unobserve(entrada.target);
                }
            });
        },
        { threshold: 0.15, rootMargin: "0px 0px -40px 0px" }
    );
    elementosRevelar.forEach((elemento) => observador.observe(elemento));
} else {
    elementosRevelar.forEach((elemento) => elemento.classList.add("visible"));
}

// Resaltamos en el menú la sección que se está viendo.
const enlacesMenu = [...menu.querySelectorAll('a[href^="#"]')];
if ("IntersectionObserver" in window) {
    const observadorSecciones = new IntersectionObserver(
        (entradas) => {
            entradas.forEach((entrada) => {
                if (!entrada.isIntersecting) return;
                enlacesMenu.forEach((enlace) => {
                    enlace.classList.toggle("activo", enlace.hash === `#${entrada.target.id}`);
                });
            });
        },
        { rootMargin: "-45% 0px -50% 0px" }
    );
    document.querySelectorAll("main section[id]").forEach((seccion) => observadorSecciones.observe(seccion));
}
