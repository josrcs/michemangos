// Configuración y utilidades compartidas por todos los scripts de la página.
// Se carga justo después de negocio.js: los demás archivos usan estas constantes y funciones.

// Número de WhatsApp al que llegan todos los pedidos; se define en negocio.js.
const whatsappNumber = NEGOCIO.whatsapp;

// En GitHub Pages, con Live Server (puertos 5500 en adelante) o abriendo el archivo
// directamente no hay servidor Express; en esos casos se usa WhatsApp y el chat local.
const API_DISPONIBLE =
    location.protocol !== "file:" &&
    !location.hostname.endsWith("github.io") &&
    !/^55\d\d$/.test(location.port);

const formatPrice = (price) => new Intl.NumberFormat("es-CO").format(price);

// Arma el enlace de WhatsApp con el mensaje escrito y codificado para la URL.
function enlaceWhatsapp(mensaje) {
    return mensaje
        ? `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(mensaje)}`
        : `https://wa.me/${whatsappNumber}`;
}

// Abre WhatsApp en otra pestaña; en el celular se abre directamente la aplicación.
function abrirWhatsapp(mensaje) {
    const enlace = document.createElement("a");
    enlace.href = enlaceWhatsapp(mensaje);
    enlace.target = "_blank";
    enlace.rel = "noopener noreferrer";
    document.body.append(enlace);
    enlace.click();
    enlace.remove();
}

// Los botones generales de WhatsApp llegan con un saludo listo para pedir.
document.querySelectorAll("[data-whatsapp]").forEach((enlace) => {
    enlace.href = enlaceWhatsapp("Hola, MicheMango. Quiero hacer un pedido 🥭");
});
