// Formulario de contacto: los pedidos van a WhatsApp y el resto al servidor.

const formularioContacto = document.getElementById("form-contacto");
const selectorTipo = document.getElementById("contacto-tipo");
const avisoPedido = document.getElementById("contacto-aviso-pedido");
const botonEnviar = formularioContacto.querySelector('button[type="submit"]');
const estadoContacto = document.getElementById("contacto-estado");

const NOMBRES_TIPO = {
    pedido: "Pedido",
    cotizacion_evento: "Cotización para evento",
    duda: "Duda",
};

// Los pedidos siempre terminan en WhatsApp; el botón lo anuncia antes de enviar.
selectorTipo.addEventListener("change", () => {
    const esPedido = selectorTipo.value === "pedido";
    avisoPedido.hidden = !esPedido;
    botonEnviar.textContent = esPedido ? "Continuar en WhatsApp" : "Enviar mensaje";
});

function mensajeParaWhatsapp(datos) {
    return [
        `Hola, MicheMango. Soy ${datos.nombre}.`,
        `Motivo: ${NOMBRES_TIPO[datos.tipo] || datos.tipo}`,
        `Mi teléfono: ${datos.telefono}`,
        "",
        datos.mensaje,
    ].join("\n");
}

function mostrarEstado(texto, tipo, mensajeWhatsapp) {
    estadoContacto.replaceChildren(texto);
    estadoContacto.className = `contacto-estado contacto-estado--${tipo}`;

    // Si WhatsApp no se abrió solo (bloqueador de ventanas), queda el enlace a mano.
    if (mensajeWhatsapp) {
        const enlace = document.createElement("a");
        enlace.href = enlaceWhatsapp(mensajeWhatsapp);
        enlace.target = "_blank";
        enlace.rel = "noopener noreferrer";
        enlace.textContent = "Abrir WhatsApp";
        estadoContacto.append(" ", enlace);
    }
}

// Guarda la solicitud en el servidor para que aparezca en el panel de administración.
async function guardarEnServidor(datos) {
    const respuesta = await fetch("/api/contacto", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(datos),
    });
    const resultado = await respuesta.json();
    if (!respuesta.ok) {
        const error = new Error(resultado.error || "No pudimos enviar tu mensaje.");
        error.validacion = respuesta.status === 400;
        throw error;
    }
    return resultado;
}

formularioContacto.addEventListener("submit", async (evento) => {
    evento.preventDefault();

    const datosFormulario = new FormData(formularioContacto);
    const datos = {
        nombre: String(datosFormulario.get("nombre")).trim(),
        telefono: String(datosFormulario.get("telefono")).trim(),
        tipo: String(datosFormulario.get("tipo")),
        mensaje: String(datosFormulario.get("mensaje")).trim(),
    };
    const mensajeWhatsapp = mensajeParaWhatsapp(datos);

    // Pedidos (o sitio publicado sin servidor): WhatsApp se abre en el mismo clic.
    if (datos.tipo === "pedido" || !API_DISPONIBLE) {
        abrirWhatsapp(mensajeWhatsapp);
        mostrarEstado("¡Listo! Te llevamos a WhatsApp con tu mensaje para confirmarlo.", "exito", mensajeWhatsapp);
        formularioContacto.reset();
        selectorTipo.dispatchEvent(new Event("change"));

        // Si hay servidor, el pedido también queda registrado en el panel.
        if (API_DISPONIBLE) guardarEnServidor(datos).catch(() => {});
        return;
    }

    estadoContacto.textContent = "";
    estadoContacto.className = "contacto-estado";
    botonEnviar.disabled = true;
    botonEnviar.textContent = "Enviando...";

    try {
        const resultado = await guardarEnServidor(datos);
        mostrarEstado(resultado.mensaje, "exito");
        formularioContacto.reset();
    } catch (error) {
        if (error.validacion) {
            mostrarEstado(error.message, "error");
        } else {
            mostrarEstado("No pudimos enviar tu mensaje. Escríbenos directamente:", "error", mensajeWhatsapp);
        }
    } finally {
        botonEnviar.disabled = false;
        selectorTipo.dispatchEvent(new Event("change"));
    }
});
