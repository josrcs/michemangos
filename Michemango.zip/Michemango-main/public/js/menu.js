// Menú móvil y cabecera que se compacta al hacer scroll.

const cabecera = document.getElementById("cabecera");
const botonMenu = document.querySelector(".menu-boton");
const menu = document.getElementById("menu-principal");

function cerrarMenu() {
    menu.classList.remove("abierto");
    botonMenu.setAttribute("aria-expanded", "false");
}

botonMenu.addEventListener("click", () => {
    const abierto = menu.classList.toggle("abierto");
    botonMenu.setAttribute("aria-expanded", String(abierto));
});

menu.querySelectorAll("a").forEach((enlace) => enlace.addEventListener("click", cerrarMenu));

document.addEventListener("keydown", (evento) => {
    if (evento.key === "Escape" && menu.classList.contains("abierto")) {
        cerrarMenu();
        botonMenu.focus();
    }
});

document.addEventListener("click", (evento) => {
    if (!cabecera.contains(evento.target)) cerrarMenu();
});

// La cabecera se compacta y gana sombra cuando el usuario baja por la página.
function revisarScroll() {
    cabecera.classList.toggle("compacto", window.scrollY > 30);
}
window.addEventListener("scroll", revisarScroll, { passive: true });
revisarScroll();
