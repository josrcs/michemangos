// Datos del negocio: única fuente para el catálogo, los precios y el número de WhatsApp.
// Lo usan la página (catálogo y recomendador) y el servidor (API e instrucciones de la IA),
// así que para cambiar un precio o agregar un producto basta con editar este archivo.
//
// Campos de cada producto:
//   id                Número único; también identifica el producto en /api/productos.
//   nombre, precio    Precio en pesos colombianos, sin puntos.
//   descripcion       Texto de la tarjeta del catálogo.
//   descripcionCorta  Resumen que usan el recomendador y las instrucciones de la IA.
//   emoji, estilo     Ilustración de la tarjeta; estilo elige el fondo .producto-arte--<estilo>.
//   etiqueta          Cinta opcional sobre la tarjeta (por ejemplo, "La favorita").
//   gustos            Raíces de palabras, sin tildes, que el recomendador local relaciona.
const NEGOCIO = {
    nombre: "MicheMango",
    ciudad: "Barranquilla",
    // Código de país (57) + celular, sin espacios ni el signo +.
    whatsapp: "573105776753",
    productos: [
        {
            id: 1,
            nombre: "Micheman",
            precio: 15000,
            descripcion:
                "Mango fresco, limón y chamoy. La combinación perfecta para empezar con un sabor intenso, refrescante y lleno de actitud.",
            descripcionCorta: "mango fresco, limón y chamoy; intenso y refrescante",
            emoji: "🥭",
            estilo: "clasico",
            gustos: ["clasic", "limon", "refresc", "chamoy", "intens"],
        },
        {
            id: 2,
            nombre: "Miche Premium",
            precio: 18000,
            descripcion:
                "Con gomitas, tajín y frutas para quienes quieren una experiencia más completa, divertida y cargada de sabor.",
            descripcionCorta: "mango con gomitas, tajín y frutas; la más dulce y completa",
            emoji: "🍬",
            estilo: "premium",
            etiqueta: "La favorita",
            gustos: ["dulce", "gomita", "fruta", "complet", "divert"],
        },
        {
            id: 3,
            nombre: "Mango Explosivo",
            precio: 20000,
            descripcion:
                "Mango, maracuyá, chamoy y tajín para una mezcla tropical con un toque ácido y picante inolvidable.",
            descripcionCorta: "mango, maracuyá, chamoy y tajín; ácido y picante",
            emoji: "🌶️",
            estilo: "explosivo",
            gustos: ["picant", "acid", "maracuya", "tajin", "explosiv", "fuerte"],
        },
        {
            id: 4,
            nombre: "Mini Miche",
            precio: 10000,
            descripcion:
                "La opción ideal para un antojo rápido: mango, limón y chamoy en una porción pequeña, pero llena de sabor.",
            descripcionCorta: "porción pequeña de mango, limón y chamoy",
            emoji: "🍋",
            estilo: "mini",
            gustos: ["pequen", "mini", "barat", "economic", "antojo", "poquito"],
        },
    ],
};

// En Node.js (servidor y pruebas) el mismo archivo se importa con require().
if (typeof module !== "undefined" && module.exports) {
    module.exports = NEGOCIO;
}
