// Catálogo: crea una tarjeta por cada producto de negocio.js y maneja cantidades,
// totales y pedidos por WhatsApp.

const MAXIMO_CANTIDAD = 50;
const listaProductos = document.getElementById("productos-lista");
const plantillaProducto = document.getElementById("plantilla-producto");

// Copiamos la plantilla del HTML y le ponemos los datos del producto como texto.
function crearTarjeta(producto) {
    const tarjeta = plantillaProducto.content.firstElementChild.cloneNode(true);
    const idCantidad = `cantidad-${producto.id}`;

    tarjeta.dataset.producto = producto.nombre;
    tarjeta.querySelector(".producto-nombre").textContent = producto.nombre;
    tarjeta.querySelector(".producto-descripcion").textContent = producto.descripcion;
    tarjeta.querySelector(".precio").textContent = `$${formatPrice(producto.precio)}`;

    const arte = tarjeta.querySelector(".producto-arte");
    arte.textContent = producto.emoji;
    arte.classList.add(`producto-arte--${producto.estilo}`);

    const cinta = tarjeta.querySelector(".producto-cinta");
    if (producto.etiqueta) {
        cinta.textContent = producto.etiqueta;
        tarjeta.classList.add("producto--destacado");
    } else {
        cinta.remove();
    }

    tarjeta.querySelector("label").htmlFor = idCantidad;
    const campoCantidad = tarjeta.querySelector(".cantidad");
    campoCantidad.id = idCantidad;
    campoCantidad.max = MAXIMO_CANTIDAD;

    const [botonQuitar, botonAgregar] = tarjeta.querySelectorAll(".cantidad-boton");
    botonQuitar.setAttribute("aria-label", `Quitar una unidad de ${producto.nombre}`);
    botonAgregar.setAttribute("aria-label", `Agregar una unidad de ${producto.nombre}`);

    prepararPedido(tarjeta, producto);
    return tarjeta;
}

// Conectamos el selector de cantidad, el total y el botón de pedido de una tarjeta.
function prepararPedido(tarjeta, producto) {
    const campoCantidad = tarjeta.querySelector(".cantidad");
    const total = tarjeta.querySelector(".producto-total strong");
    const botonPedido = tarjeta.querySelector(".pedido-button");

    function leerCantidad() {
        const cantidad = Number(campoCantidad.value);
        return Number.isInteger(cantidad) && cantidad >= 1 && cantidad <= MAXIMO_CANTIDAD ? cantidad : null;
    }

    // Actualizamos el total; al cambiarlo da un pequeño salto para que se note.
    function actualizarTotal(animar = true) {
        const cantidad = leerCantidad();
        total.textContent = cantidad ? `$${formatPrice(producto.precio * cantidad)}` : "—";
        if (!animar) return;
        total.classList.remove("salto");
        void total.offsetWidth;
        total.classList.add("salto");
    }

    tarjeta.querySelectorAll(".cantidad-boton").forEach((boton) => {
        boton.addEventListener("click", () => {
            const actual = leerCantidad() || 1;
            const nueva = Math.min(MAXIMO_CANTIDAD, Math.max(1, actual + Number(boton.dataset.paso)));
            campoCantidad.value = nueva;
            campoCantidad.setCustomValidity("");
            actualizarTotal();
        });
    });

    campoCantidad.addEventListener("input", () => {
        campoCantidad.setCustomValidity("");
        actualizarTotal();
    });

    botonPedido.addEventListener("click", () => {
        const cantidad = leerCantidad();

        if (!cantidad) {
            campoCantidad.setCustomValidity(`Ingresa una cantidad entre 1 y ${MAXIMO_CANTIDAD}.`);
            campoCantidad.reportValidity();
            campoCantidad.focus();
            return;
        }

        const mensaje = [
            `Hola, ${NEGOCIO.nombre}. Quiero hacer este pedido:`,
            `- ${cantidad} x ${producto.nombre} ($${formatPrice(producto.precio)} c/u)`,
            `Total: $${formatPrice(producto.precio * cantidad)}`,
        ].join("\n");

        abrirWhatsapp(mensaje);
    });

    actualizarTotal(false);
}

listaProductos.append(...NEGOCIO.productos.map(crearTarjeta));
