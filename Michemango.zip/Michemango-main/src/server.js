const path = require("path");

// Cargamos la configuración privada del .env (en la raíz del proyecto) antes de iniciar Express.
require("dotenv").config({ path: path.join(__dirname, "..", ".env") });

// Importamos Express, las rutas y los datos del negocio (compartidos con la página).
const express = require("express");
const session = require("express-session");
const NEGOCIO = require("../public/js/negocio");
const contactoRouter = require("./routes/contacto");
const chatRouter = require("./routes/chat");
const adminRouter = require("./routes/admin");
const adminApiRouter = require("./routes/adminApi");

// Creamos la aplicación y ubicamos la carpeta pública del sitio.
const app = express();
const PUERTO = process.env.PORT || 3000;
const CARPETA_PUBLICA = path.join(__dirname, "..", "public");

// Sin credenciales el sitio sigue funcionando; solo el panel queda deshabilitado.
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD_HASH) {
  console.warn("Panel de administración deshabilitado: configura ADMIN_USERNAME y ADMIN_PASSWORD_HASH en .env.");
} else if (!/^\$2[aby]\$\d{2}\$/.test(process.env.ADMIN_PASSWORD_HASH)) {
  throw new Error("ADMIN_PASSWORD_HASH debe contener un hash bcrypt válido.");
}

// Sin secreto propio usamos uno aleatorio: las sesiones se pierden al reiniciar el servidor.
let secretoSesion = process.env.SESSION_SECRET;
if (!secretoSesion || secretoSesion.length < 32) {
  if (process.env.NODE_ENV === "production") {
    throw new Error("SESSION_SECRET en .env debe tener al menos 32 caracteres.");
  }
  console.warn("SESSION_SECRET no está configurado; se usará uno temporal.");
  secretoSesion = require("crypto").randomBytes(32).toString("hex");
}

// Si hay un proxy HTTPS al desplegar, Express podrá reconocer la conexión segura.
if (process.env.NODE_ENV === "production") {
  app.set("trust proxy", 1);
}

// Creamos sesiones antes de las rutas que comprueban si el usuario inició sesión.
app.use(
  session({
    name: "michemango.sid",
    secret: secretoSesion,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 1000,
    },
  })
);

// Servimos los archivos públicos y protegemos la API de administración antes de leer su cuerpo.
app.use(express.static(CARPETA_PUBLICA));
app.use("/api/admin", adminApiRouter);

// Permitimos recibir datos JSON para el formulario y el inicio de sesión.
app.use(express.json({ limit: "10kb" }));

// Conectamos las rutas relacionadas con las solicitudes de contacto.
app.use("/api", contactoRouter);
app.use("/api", chatRouter);
app.use("/admin", adminRouter);

// Entregamos el mismo catálogo que muestra la página.
app.get("/api/productos", (req, res) => {
  res.json(NEGOCIO.productos);
});

// Contestamos con JSON cuando se solicita una ruta de API que no existe.
app.use("/api", (req, res) => {
  res.status(404).json({ error: "La ruta de la API no existe." });
});

// Informamos claramente si el cuerpo JSON enviado por el navegador no se puede leer.
app.use((error, req, res, next) => {
  if (error.type === "entity.parse.failed") {
    return res.status(400).json({ error: "Los datos enviados no tienen formato JSON válido." });
  }

  if (error.type === "entity.too.large") {
    return res.status(413).json({ error: "Los datos enviados superan el tamaño permitido." });
  }

  console.error("Error inesperado del servidor:", error);
  return res.status(500).json({ error: "Ocurrió un error inesperado en el servidor." });
});

// Al iniciar este archivo directamente, dejamos al servidor escuchando en el puerto.
if (require.main === module) {
  app.listen(PUERTO, () => {
    console.log(`MicheMango está disponible en http://localhost:${PUERTO}`);
  });
}

// Exportamos la aplicación para poder probar sus rutas sin iniciar otro servidor.
module.exports = app;
