# 🥭 MicheMango

## Descripción

MicheMango es una página web creada para promocionar y vender miche de mango. Su objetivo es ofrecer a los clientes una forma sencilla de conocer los productos, los precios y la información del emprendimiento.

## Objetivos

- Dar a conocer la marca MicheMango.
- Mostrar el catálogo de productos.
- Facilitar el contacto con los clientes.
- Impulsar las ventas del emprendimiento.

## Tecnologías utilizadas

- HTML5
- CSS3
- JavaScript
- Node.js
- Express
- express-session
- bcryptjs
- dotenv
- @anthropic-ai/sdk
- Git
- GitHub y GitHub Pages

## Estructura del proyecto

El proyecto tiene dos partes: `public/` es lo que ve el visitante (y lo único que
se publica en GitHub Pages) y `src/` es el servidor Express.

```text
Michemango/
├── public/                     Sitio web (HTML, CSS y JavaScript del navegador)
│   ├── index.html              Página principal
│   ├── css/
│   │   └── styles.css          Todos los estilos, animaciones y diseño adaptable
│   └── js/
│       ├── negocio.js          Productos, precios y WhatsApp (única fuente de datos)
│       ├── config.js           Utilidades compartidas: enlaces de WhatsApp, precios
│       ├── catalogo.js         Crea las tarjetas y maneja cantidades y pedidos
│       ├── menu.js             Menú móvil y cabecera
│       ├── animaciones.js      Apariciones al hacer scroll y enlace activo del menú
│       ├── contacto.js         Formulario de contacto
│       ├── chatbot.js          Recomendador (IA del servidor o versión local)
│       └── admin/
│           ├── login.js        Formulario de ingreso al panel
│           └── panel.js        Tabla de solicitudes del panel
├── src/                        Servidor Express (npm start)
│   ├── server.js               Punto de entrada: configura Express y conecta las rutas
│   ├── routes/
│   │   ├── contacto.js         POST /api/contacto
│   │   ├── chat.js             POST /api/chat (consulta a Anthropic)
│   │   ├── admin.js            /admin, /admin/login y /admin/logout
│   │   └── adminApi.js         /api/admin/solicitudes (requiere sesión)
│   ├── middleware/
│   │   └── requiereAdmin.js    Bloquea las rutas privadas sin sesión
│   ├── data/
│   │   ├── solicitudes.js      Lee y guarda las solicitudes
│   │   └── solicitudes.json    Se crea con la primera solicitud (no se sube a Git)
│   ├── prompts/
│   │   └── chatbotSistema.js   Instrucciones de la IA (arma el catálogo desde negocio.js)
│   └── views/                  Páginas privadas del panel (las sirve Express)
│       ├── admin-login.html
│       └── admin.html
├── test/
│   └── api.test.js             Pruebas automáticas del servidor y los datos (npm test)
├── .github/workflows/pages.yml Ejecuta las pruebas y publica public/ en GitHub Pages
├── index.html                  Redirige a public/ (para abrir con Live Server)
├── .env.example                Variables de entorno de ejemplo
├── package.json
└── README.md
```

### Dónde cambiar cada cosa

- **Productos, precios y número de WhatsApp:** solo en `public/js/negocio.js`.
  De ahí salen las tarjetas del catálogo, el recomendador local, la ruta
  `GET /api/productos` y las instrucciones de la IA. Para agregar un producto,
  copia uno de los objetos de la lista y cambia sus datos; si usas un `estilo`
  nuevo, crea la clase `.producto-arte--<estilo>` en `styles.css`.
  Los `href` de WhatsApp escritos en el HTML se reemplazan desde JavaScript y se
  dejan solo por si JavaScript no carga.
- **Diseño de la tarjeta de producto:** la plantilla `<template id="plantilla-producto">`
  de `public/index.html`; `catalogo.js` la copia y la llena con cada producto.
- **Colores y tipografías:** las variables de `:root` al inicio de
  `public/css/styles.css`. Las animaciones (`@keyframes`) están al final.
- **Tono y reglas de la IA:** `src/prompts/chatbotSistema.js`.
- **Orden de los scripts:** son scripts clásicos que comparten variables globales,
  por eso el orden de `index.html` importa: `negocio.js` → `config.js` →
  `catalogo.js` (crea las tarjetas) → `menu.js` → `animaciones.js` (busca los
  elementos a revelar, incluidas las tarjetas) → `contacto.js` → `chatbot.js`.

## Pruebas

```bash
npm test
```

Usa el ejecutor de pruebas incluido en Node.js (sin dependencias extra). Revisa que
cada producto tenga los campos necesarios, que la API y las instrucciones de la IA
usen el mismo catálogo, las validaciones del formulario y del chat, y que el panel
exija iniciar sesión. No escribe en `solicitudes.json` ni consulta a Anthropic. En
GitHub las pruebas se ejecutan antes de cada publicación y, si fallan, el sitio no
se actualiza.

## Servidor de desarrollo y formulario de contacto

Express sirve los archivos de la carpeta `public`, conserva el catálogo en
`/api/productos` y recibe los mensajes del formulario en `POST /api/contacto`.
La ruta valida los datos en el servidor y guarda cada solicitud en
`src/data/solicitudes.json`; este archivo se crea al enviar el primer formulario y
está excluido de Git porque contiene datos personales.

Para iniciar el servidor desde la carpeta raíz del proyecto:

```bash
npm install
npm start
```

Si usas Windows PowerShell y aparece un error indicando que no se puede ejecutar
`npm.ps1`, usa `npm.cmd` en lugar de `npm` (por ejemplo, `npm.cmd start`).

Después de iniciarlo, visita `http://localhost:3000/` para ver el sitio o
`http://localhost:3000/api/productos` para consultar el catálogo.

También puedes abrir el sitio con la extensión Live Server de VS Code: la raíz
está configurada en `public/`. Sin el servidor de Node no funcionan el panel ni
la IA del chat; los pedidos y el formulario se envían por WhatsApp.

### Acceso al panel de administración

Copia `.env.example` como `.env` y configura un usuario, el hash bcrypt de la
contraseña y un secreto de sesión aleatorio de al menos 32 caracteres. Para
crear el hash de una contraseña desde la terminal puedes ejecutar:

```bash
node -e "require('bcryptjs').hash('TU_CONTRASENA', 12).then(console.log)"
```

Pega el resultado en `ADMIN_PASSWORD_HASH` dentro de `.env`. No compartas ese
archivo ni lo subas a Git; `.gitignore` ya lo excluye. El panel está en
`http://localhost:3000/admin/login`. La tabla permite cambiar el estado entre
`nueva` y `atendida`, y eliminar solicitudes.

Una **sesión** es un registro temporal en el servidor que recuerda que ya
iniciaste sesión; el navegador conserva solo una cookie identificadora. La
contraseña se guarda como hash porque el hash permite comprobarla sin almacenar
el texto secreto original.

El almacenamiento de sesiones predeterminado de Express sirve para aprender y
probar localmente, pero se borra al reiniciar el servidor y no está diseñado para
un despliegue real con varias instancias.

### Chatbot recomendador

El botón flotante abre un chat que recomienda entre los productos de `negocio.js` según
los gustos y el presupuesto. El navegador envía el historial reciente a
`POST /api/chat`; Express valida que cada mensaje tenga como máximo 500
caracteres y consulta a Anthropic usando las instrucciones de
`src/prompts/chatbotSistema.js`. La API key y el modelo se configuran en `.env` como
`ANTHROPIC_API_KEY` y `ANTHROPIC_MODEL`. El ejemplo usa `claude-haiku-5-5`; puedes
cambiarlo por otro ID habilitado en tu cuenta.

Agrega tu API key de Anthropic a `.env` para activar recomendaciones reales. Si
la key falta, el servidor sigue funcionando, pero la ruta del chat responde con
un error 503 amigable. Nunca pongas la key en `public/chatbot.js` ni en el HTML:
el navegador y sus solicitudes son visibles para los visitantes.

Una key incorrecta, sin acceso al modelo o sin crédito disponible produce un
mensaje para volver a intentar; revisa la key, el modelo configurado y el estado
de tu cuenta. El modelo configurado se puede comparar con la
[lista oficial de modelos de Claude](https://platform.claude.com/docs/en/models/overview).
Si aparece que la key está incompleta, confirma que hayas pegado la API key real
completa de Anthropic en `.env`; una contraseña o un código numérico no es una API key.

### Límite del almacenamiento JSON

El archivo JSON sirve para aprender y para un uso local pequeño, pero no está
diseñado para varias instancias del servidor o muchas escrituras simultáneas.
Además, si el equipo se apaga o el archivo se daña, se pueden perder solicitudes.
Más adelante conviene usar una base de datos y un servicio de backend desplegado.

## Publicación en GitHub Pages

El flujo `.github/workflows/pages.yml` publica la carpeta `public` cada vez que
se sube un cambio a la rama `main`. Para activarlo, en GitHub entra a
**Settings → Pages** y en **Source** elige **GitHub Actions**.

GitHub Pages solo sirve archivos estáticos, así que en el sitio publicado:

- Los pedidos y el formulario de contacto abren WhatsApp (+57 310 577 6753) con
  el mensaje ya escrito.
- El recomendador usa una versión local por gustos y presupuesto; con el
  servidor Express y la API key responde la IA de Anthropic.
- El panel de administración solo funciona con el servidor (`npm start`).

## Funcionalidades

- Página de inicio.
- Catálogo de productos.
- Información del emprendimiento.
- Contacto con formulario; los pedidos se envían por WhatsApp.
- Pedidos por WhatsApp desde cada producto, con cantidad y total calculado.
- Recomendador de miches con IA (y versión local sin servidor).
- Animaciones hechas con CSS y JavaScript: mango animado en la portada,
  apariciones al hacer scroll, cinta de sabores y botones con rebote. Se
  desactivan si el sistema pide reducir el movimiento.
- Diseño adaptable para dispositivos móviles.

## Autor

Rafael Lombana

## Estado del proyecto

🚧 En desarrollo.